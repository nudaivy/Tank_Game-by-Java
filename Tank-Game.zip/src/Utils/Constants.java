package Utils;
/**
* @Author Dawei Xu
* @CreateTime 
* @Version 
* @Since 
* @Description all constants in the game
*/

import java.awt.Font;

public class Constants {

	public static final String GAME_TITLE = "D-X Tank Game";
	/*
	 * frame width and height
	 */
	public static final int FRAME_WIDTH = 1200;
	public static final int FRAME_HEIGHT = 700;
	/*
	 * frame location in windows
	 */
	public static final int GAME_X = 1620-FRAME_WIDTH >> 1;
	public static final int GAME_Y = 900-FRAME_HEIGHT >> 1;
	/*
	 * define five status
	 */
	public static final int STATUS_MENU = 0;
	public static final int STATUS_HELP = 1;
	public static final int STATUS_ABOUT = 2;
	public static final int STATUS_RUNNING = 3;
	public static final int STATUS_OVER = 4;
	/*
	 * main menu display on game frame
	 */
	public static final String[] GAME_MENU = {
		"Start Game",
		"Game  Help",
		"About Game",
		" Contunue ",
		"    Exit  "
	};
	/*
	 * font for menu
	 */
	public static final Font Menu_FONT = new Font("microsoft yahei", Font.PLAIN, 30);
			
	public static final long REPAINT_INTERVAL = 100;
}
