package Utils;

import java.awt.Color;

/**
 * @Author Dawei Xu
 * @CreateTime
 * @Version
 * @Since
 * @Description all util methods are defined here
 */
public class MyUtils {

	/**
	 * get a random number
	 * 
	 * @param min minimum number included
	 * @param max maximum number excluded
	 * @return a random number
	 */
	public static final int getRandomNum(int min, int max) {
		return (int) (Math.random() * (max - min) + min);
	}

	/**
	 * get a random color by three random parameters
	 * @return a random color
	 */
	public static final Color getRandomColor() {
		int red = getRandomNum(0, 256);
		int green = getRandomNum(0, 256);
		int blue = getRandomNum(0, 256);
		return new Color(red, green,blue);
		
	}
}
