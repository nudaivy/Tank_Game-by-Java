package app;

import Frame.GameFrame;

/**
* @Author Dawei Xu
* @CreateTime 
* @Version 
* @Since 
* @Description 
*/
public class MainGame {
	public static void main(String[] args) {
		new GameFrame();
	}

}
