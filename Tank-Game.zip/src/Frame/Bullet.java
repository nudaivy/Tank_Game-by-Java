package Frame;
/**
* @Author Dawei Xu
* @CreateTime 
* @Version 
* @Since 
* @Description 
*/

import java.awt.Color;
import java.awt.Graphics;

public class Bullet {

	public static final int DEFAULT_SPEED = Tank.DEFAULT_SPEED << 1;
	public static final int BULLET_RADIUS = 4;

	private int speed;// bullet speed
	private int dir;// bullet direction
	private Color color;// bullet color
	private int atk; // bullet attack
	private int x,y;// bullet location
	
	
	public Bullet(int dir, Color color, int atk, int x, int y) {
		this.dir = dir;
		this.color = color;
		this.atk = atk;
		this.x = x;
		this.y = y;
		speed = DEFAULT_SPEED;
	}
	/**
	 * draw bullet by graphics
	 * @param g
	 */
	public void drawBullet(Graphics g) {
		bulletLogic();
		g.setColor(color);
		g.fillOval(x-BULLET_RADIUS, y-BULLET_RADIUS, BULLET_RADIUS<<1, BULLET_RADIUS<<1);
	}
	
	
	/**
	 * locate bullet position from different direction
	 * x and y value varies with speed
	 */
	private void bulletLogic() {
		switch(dir) {
		case Tank.DIR_DOWN:
			y += speed;
			break;
		case Tank.DIR_UP:
			y -= speed;
			break;
		case Tank.DIR_LEFT:
			x -= speed;
			break;
		case Tank.DIR_RIGHT:
			x += speed;
			break;
		}
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getDir() {
		return dir;
	}

	public void setDir(int dir) {
		this.dir = dir;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public int getAtk() {
		return atk;
	}

	public void setAtk(int atk) {
		this.atk = atk;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	
	
}
