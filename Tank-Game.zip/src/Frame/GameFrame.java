package Frame;

import Utils.Constants;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

/**
 * @Author Dawei Xu
 * @CreateTime 2022.02.04
 * @Version
 * @Since
 * @Description
 */
@SuppressWarnings("serial")
public class GameFrame extends Frame implements Runnable {

	private static int gameStatus;// game status is used to store game status from 0-4
	private int currentMenu;// menu which is being selected
	public static int titleBarHeight; // top bar height of game frame
	private BufferedImage bufferedImage;// this buffered image will be same size with game frame
	private Tank myTank;
	
	public GameFrame() {
		initGameFrame();
		initEventListener();
		initGame();
		new Thread(this).start();
	}

	/**
	 * initialize game frame's size, title and location
	 */
	private void initGameFrame() {
		// title here should be instant which will help managing it if needed
		/*
		 * set title of game frame
		 */
		setTitle(Constants.GAME_TITLE);
		/*
		 * set the frame to be visible
		 */
		setVisible(true);
		/*
		 * set width and height of game frame
		 */
		setSize(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
		/*
		 * set position of frame in windows by value of X, Y
		 */
		setLocation(Constants.GAME_X, Constants.GAME_Y);
		/*
		 * set the frame size fixed
		 */
		setResizable(false);
		/*
		 * after game frame initialized, the top bar height can be got by 
		 * method  getInsets().top
		 */
		
	}

	/**
	 * when game started, this method is to initiate all initial status such as
	 * display
	 */
	private void initGame() {
		gameStatus = Constants.STATUS_MENU;
		titleBarHeight = getInsets().top;
		bufferedImage = new BufferedImage(Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT, BufferedImage.TYPE_4BYTE_ABGR);
	}

	/**
	 * this is to draw different menu according to game status this method will only
	 * be recalled when method repaint() is called
	 * 
	 * @param graphics class Graphics given by system to draw photo
	 */
	public void paint(Graphics graphics) {
		Graphics g = bufferedImage.getGraphics();
		g.setFont(Constants.Menu_FONT);
		switch (gameStatus) {
		case Constants.STATUS_MENU:
			drawMenu(g);
			break;
		case Constants.STATUS_ABOUT:
			drawAbout(g);
			break;
		case Constants.STATUS_HELP:
			drawHelp(g);
			break;
		case Constants.STATUS_RUNNING:
			drawRunning(g);
			break;
		case Constants.STATUS_OVER:
			drawOver(g);
			break;

		}
		graphics.drawImage(bufferedImage, 0, 0, null);
	}

	private void drawOver(Graphics g) {
	}

	/**
	 * draw a display when the game status is running
	 * @param g
	 */
	private void drawRunning(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);
		myTank.drawTank(g);
		
	}

	private void drawHelp(Graphics g) {
	}

	private void drawAbout(Graphics g) {

	}

	/**
	 * this is to draw game menu
	 * 
	 * @param g
	 */
	private void drawMenu(Graphics g) {

		g.setColor(Color.BLACK);
		/*
		 * fill rectangle by x line from 0 - frame width, y line from 0 - frame height
		 */
		g.fillRect(0, 0, Constants.FRAME_WIDTH, Constants.FRAME_HEIGHT);

		/*
		 * MENU_LENTH is a general length of characters in each line of menu
		 */
		final int MENU_LENTH = 200;
		/*
		 * MENU_DISTANCE is distance between each line of menu
		 */
		final int MENU_DISTANCE = 70;
		int x = Constants.FRAME_WIDTH - MENU_LENTH >> 1;
		int y = Constants.FRAME_HEIGHT / 3;
		/*
		 * method drawString is draw strings on the window. it will draw game menu with
		 * location x and y
		 */
		for (int i = 0; i < Constants.GAME_MENU.length; i++) {
			if (i == currentMenu) {
				g.setColor(Color.WHITE);
			} else {
				g.setColor(Color.GREEN);
			}
			g.drawString(Constants.GAME_MENU[i], x, y + i * MENU_DISTANCE);
		}

	}

	/**
	 * this method is to initialize and add all event listeners
	 */
	private void initEventListener() {
		/*
		 * add a window listener to close window
		 */
		addWindowListener(new WindowAdapter() {
			/*
			 * window close event
			 */
			@Override
			public void windowClosing(WindowEvent event) {
				System.exit(0);
			}
		});

		/*
		 * key listener is for all key events
		 */
		addKeyListener(new KeyAdapter() {
			/*
			 * key pressed means key event e will happen when key is pressed key code can be
			 * got by key event e here need to note that different menu status will have
			 * different key event rules in each menu, event will be different from
			 * different keys pressed
			 */
			@Override
			public void keyPressed(KeyEvent e) {
				int keyCode = e.getKeyCode();
				switch (gameStatus) {
				case Constants.STATUS_MENU:
					keyEventMenu(keyCode);
					break;
				case Constants.STATUS_ABOUT:
					keyEventAbout(keyCode);
					break;
				case Constants.STATUS_HELP:
					keyEventHelp(keyCode);
					break;
				case Constants.STATUS_RUNNING:
					keyEventRunning(keyCode);
					break;
				case Constants.STATUS_OVER:
					keyEventOver(keyCode);
					break;

				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				int keycode = e.getKeyCode();
				if(gameStatus == Constants.STATUS_RUNNING) {
					keyReleasedEvent(keycode);
				}
			}

		});

	}

	/**
	 * when key released, change tank status from move to be stand
	 * @param keycode
	 */
	protected void keyReleasedEvent(int keycode) {
		switch(keycode) {
		case KeyEvent.VK_UP:
		case KeyEvent.VK_DOWN:
		case KeyEvent.VK_LEFT:
		case KeyEvent.VK_RIGHT:
		case KeyEvent.VK_W:
		case KeyEvent.VK_S:
		case KeyEvent.VK_D:
		case KeyEvent.VK_A:
		myTank.setTankStatus(Tank.TANK_STAND);
		}
	}

	protected void keyEventOver(int keyCode) {
	
	}

	/**
	 * key event when game is running
	 * 
	 * @param keyCode is key value got by key event
	 */
	protected void keyEventRunning(int keyCode) {
		/*
		 * set direction of tank when pressing different key
		 */
		switch(keyCode) {
		case KeyEvent.VK_UP:
		case KeyEvent.VK_W:
			myTank.setDir(Tank.DIR_UP);
			myTank.setTankStatus(Tank.TANK_MOVE);
			break;
		case KeyEvent.VK_DOWN:
		case KeyEvent.VK_S:
			myTank.setDir(Tank.DIR_DOWN);
			myTank.setTankStatus(Tank.TANK_MOVE);
			break;
		case KeyEvent.VK_LEFT:
		case KeyEvent.VK_A:
			myTank.setDir(Tank.DIR_LEFT);
			myTank.setTankStatus(Tank.TANK_MOVE);
			break;
		case KeyEvent.VK_RIGHT:
		case KeyEvent.VK_D:
			myTank.setDir(Tank.DIR_RIGHT);
			myTank.setTankStatus(Tank.TANK_MOVE);
			break;
		case KeyEvent.VK_SPACE:
			myTank.takeFire();
			break;
		}
		
	}

	protected void keyEventHelp(int keyCode) {
	}

	protected void keyEventAbout(int keyCode) {
	}

	/**
	 * define key rules when key event is menu
	 * different key code will have different event such as w and up in keyboard means going up
	 * when the current menu is at top, then it will go to the bottom if keeping pressing key up or w
	 * when the current menu is at bottom, then it will to to top if keeping pressing key down or s
	 * @param keyCode
	 */
	protected void keyEventMenu(int keyCode) {
		switch (keyCode) {
		case KeyEvent.VK_UP:
		case KeyEvent.VK_W:
			currentMenu--;
			if(currentMenu < 0) {
				currentMenu = Constants.GAME_MENU.length - 1;
			}
			break;
		case KeyEvent.VK_DOWN:
		case KeyEvent.VK_S:
			currentMenu++;
			if(currentMenu > Constants.GAME_MENU.length - 1) {
				currentMenu = 0;
			}
			break;
		case KeyEvent.VK_ENTER:
			newGame();
			break;

		}
	}

	/**
	 * when key press is enter, it will call this method
	 * new game will change the game status from menu to be running
	 * initialize tank object with position value x,y and direction
	 */
	private void newGame() {
		gameStatus = Constants.STATUS_RUNNING;
		myTank = new Tank(300, 100, Tank.DIR_UP);
		
	}

	/**
	 * this thread will run method repaint every 30 milliseconds
	 */
	@Override
	public void run() {
		while(true) {
			repaint();
			try {
				Thread.sleep(Constants.REPAINT_INTERVAL);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
