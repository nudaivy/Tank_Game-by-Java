package Frame;
/**
* @Author Dawei Xu
* @CreateTime 
* @Version 
* @Since 
* @Description 
*/

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import Utils.Constants;
import Utils.MyUtils;

public class Tank {

	public static final int DIR_DOWN = 0;// tank direction
	public static final int DIR_UP = 1;
	public static final int DIR_LEFT = 2;
	public static final int DIR_RIGHT = 3;
	
	public static final int DEFAULT_HP = 1000;// default hp value
	public static final int DEFAULT_SPEED = 15; // 4 in each frame
	public static final int RADIUS = 15;// radius of tank
	
	public static final int TANK_STAND = 0;
	public static final int TANK_MOVE = 1;
	public static final int TANK_DIE = 2;
	/*
	 * starting position of tank. consider tank as a circle
	 * x, y is position of center point of circle
	 */
	private int x,y; // tank position
	private int atk;// tank attack
	private int speed; // tank speed
	private int dir;// tank direction
	private int tankStatus;// tank status
	private Color color;// tank color
	
	private List<Bullet> bullets = new ArrayList<Bullet>();// bullets container

	public Tank(int x, int y, int dir) {
		this.x = x;
		this.y = y;
		this.dir = dir;
		speed = DEFAULT_SPEED;
		tankStatus = TANK_STAND;
		color = MyUtils.getRandomColor();
	}
	
	public void drawTank(Graphics g) {
		tankMoveLogic();// every move of tank need display to be drawn again
		
		tankGraphics(g);
		
		tankBullets(g);
	}
	/**
	 * this is to draw tanks
	 * @param graphics is system class for drawing
	 */
	private void tankGraphics(Graphics g) {
		g.setColor(color);
		g.fillOval(x-RADIUS, y-RADIUS, RADIUS<<1, RADIUS<<1);
		int endX = x;
		int endY = y;
		switch(dir) {
		case DIR_DOWN:
			endY = y + RADIUS*2;
			g.drawLine(x-1, y, endX-1, endY);
			g.drawLine(x+1, y, endX+1, endY);
			break;
		case DIR_UP:
			endY = y - RADIUS*2;
			g.drawLine(x-1, y, endX-1, endY);
			g.drawLine(x+1, y, endX+1, endY);
			break;
		case DIR_LEFT:
			endX = x - RADIUS*2;
			g.drawLine(x, y-1, endX, endY-1);
			g.drawLine(x, y+1, endX, endY+1);
			break;
		case DIR_RIGHT:
			endX = x + RADIUS*2;
			g.drawLine(x, y-1, endX, endY-1);
			g.drawLine(x, y+1, endX, endY+1);
			break;
		}
		g.drawLine(x, y, endX, endY);
	}
	/**
	 * this is to define tank move logic
	 */
	private void tankMoveLogic() {
		switch(tankStatus) {
		case TANK_STAND:
			break;
		case TANK_MOVE:
			tankMove();
			break;
		case TANK_DIE:
			break;
		}
	}
	/**
	 * when tank move, its x and y value will change
	 * different direction will have different rules locate x and y
	 */
	private void tankMove() {
		switch(dir) {
		case DIR_UP:
			y -= speed;
			if(y < RADIUS + GameFrame.titleBarHeight) {
				y = RADIUS + GameFrame.titleBarHeight;
			}
			break;
		case DIR_DOWN:
			y += speed;
			if(y > Constants.FRAME_HEIGHT - RADIUS) {
				y = Constants.FRAME_HEIGHT - RADIUS;
			}
			break;
		case DIR_LEFT:
			x -= speed;
			if(x < RADIUS) {
				x = RADIUS;
			}
			break;
		case DIR_RIGHT:
			x += speed;
			if(x > Constants.FRAME_WIDTH - RADIUS) {
				x = Constants.FRAME_WIDTH - RADIUS;
			}
			break;
		}
	}
	
	public void takeFire() {
		int bulletX = x;
		int bulletY = y;
		switch(dir) {
		case DIR_DOWN:
			bulletY += RADIUS*2;
			break;
		case DIR_UP:
			bulletY -= RADIUS*2;
			break;
		case DIR_LEFT:
			bulletX -= RADIUS*2;
			break;
		case DIR_RIGHT:
			bulletX += RADIUS*2;
			break;
		}
		Bullet bullet = new Bullet(dir, color, atk, bulletX, bulletY);
		bullets.add(bullet);
	}
	
	private void tankBullets(Graphics g) {
		for(Bullet bullet : bullets	) {
			bullet.drawBullet(g);
		}
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getAtk() {
		return atk;
	}
	public void setAtk(int atk) {
		this.atk = atk;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getDir() {
		return dir;
	}
	public void setDir(int dir) {
		this.dir = dir;
	}
	public int getTankStatus() {
		return tankStatus;
	}
	public void setTankStatus(int tankStatus) {
		this.tankStatus = tankStatus;
	}
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	public List getBullets() {
		return bullets;
	}
	public void setBullets(List bullets) {
		this.bullets = bullets;
	}
	
	
}
