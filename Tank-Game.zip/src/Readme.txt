1, initialize game window frame: size, location, close event;
2, make game menu window.
	in menu, there are several status such as menu,help, about,exit,proceeding. 
	each status will have different display and different event
	all those status are fixed so it should be declared to be constant.
3, when menu selected, the font color should be different from other menu fonts
4, add select event on each menu, such as keyboard listener
5, design and graphic tank, tank direction and movement
6, design bullets
7, change graphic tank by image
8, solve screen flashing problem by double buffer within four steps.
	Reason: before, i am using system graphics to draw game window images directly
			now, i am going to build a buffered image same size with game window
			and then draw everything on buffered image by buffered image graphics
			at last, use system graphics to draw this buffered image on game window
			
	step 1, define one buffered image by class BufferedImage. width and height same as game frame. 
			image type is BufferedImage.4byte_ARGB
	step 2, in paint method, get buffered image graphics by getGraphics(),
	step 3, use this graphics to draw what we draw before
	step 4, draw buffered image by system graphics with param (buffered image,0,0,null)
